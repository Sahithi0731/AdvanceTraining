package problemstatement7_2;

public class NameNotValidException extends Exception{
	public String validname()
    {
         return ("Name is not Valid..Please Retype the Name");
    }
}
